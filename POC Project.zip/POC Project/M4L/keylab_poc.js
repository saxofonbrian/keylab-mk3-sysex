// keylab_poc.js — proof of concept: arm buttons (bottom row) + locator list (7 lines)
// Arturia KeyLab 88/61 mk3 in DAW mode. One device, one track, one file.
//
// Patch: midiin -> midiparse -> (control) -> prepend ctl -> js -> midiout
//        live.thisdevice -> delay 1000 -> [init( -> js
//
// init also runs on CC44 (the Redo button) and on clicking [init( in the patch.
// [connect( sends the DAW connect handshake on its own.
//
// Run init after every edit to this file: autowatch reloads the script WITHOUT
// live.thisdevice firing, so init() is never called, nothing works, and there
// is no error in the Max console to tell you why.

autowatch = 1;
inlets = 1;
outlets = 1;

// ---------------- configuration ----------------

var TITLE       = "Locators";
var VISIBLE     = 7;          // the screen holds 7 list lines
var GAP_MS      = 60;         // spacing between screen packets — two 00 02 04
                              // packets sent back to back can race on the device
var TRACK_COUNT = 4;          // the first four tracks in the set
var MAX_LABEL   = 12;         // button label length
var MAX_LINE    = 18;         // list line length

var CC_BTN  = [49, 50, 51, 52];   // screen buttons 1-4 = the bottom row
var CC_JOG  = 116;
var CC_PLAY = 21;
var CC_STOP = 20;
var CC_INIT = 44;

var COLOR_ARMED = [0x00, 0x7F, 0x00];   // green = armed
var COLOR_OFF   = [0x00, 0x14, 0x00];   // dim

// ---------------- state ----------------

var ready  = false;
var names  = [];      // track names, read from Live
var armed  = [];      // 0/1 per track
var songs  = [];      // {idx, name, time, nextTime} built from the locators
var cursor = 0;       // selected line
var top    = 0;       // topmost visible line

var boundaryTime = -1;      // where the playing song ends (-1 = guard off)
var playing      = false;   // from the is_playing observer
var timeObserver = null;    // both observers must live in globals, or the
var playObserver = null;    // garbage collector removes them

var queue     = [];
var sending   = false;
var queueTask = new Task(sendNext);   // ONE fixed Task, reused — never a new Task
                                      // per message, or Max collects it mid-flight

// ---------------- init ----------------

function bang() {
    init();
}

// Forces the KeyLab into DAW mode regardless of what else has touched the
// port. Same handshake Arturia's own Live script sends. Without it the screen
// stays dead whenever the keyboard is powered on after the DAW.
function connect() {
    enqueue([0x00, 0x02, 0x05, 0x01]);
}

function init() {
    ready        = false;
    names        = [];
    armed        = [];
    songs        = [];
    boundaryTime = -1;

    var liveSet = new LiveAPI("live_set");

    // tracks 1-4
    var count = Math.min(TRACK_COUNT, liveSet.getcount("tracks"));
    for (var i = 0; i < count; i++) {
        var track = new LiveAPI("live_set tracks " + i);
        names.push(textOf(track.get("name")));
        armed.push(track.get("arm")[0] ? 1 : 0);
    }

    scanLocators();
    cursor = 0;
    top    = 0;

    if (timeObserver) timeObserver.property = "";
    if (playObserver) playObserver.property = "";

    playObserver = new LiveAPI(onIsPlayingChanged, "live_set");
    playObserver.property = "is_playing";
    playing = playObserver.get("is_playing")[0] ? true : false;

    timeObserver = new LiveAPI(onTimeChanged, "live_set");
    timeObserver.property = "current_song_time";

    queue   = [];
    sending = false;

    connect();                                // handshake first
    for (var j = 0; j < names.length; j++) drawButton(j);
    drawList();

    ready = true;
    post("keylab_poc: ready — " + names.length + " tracks, " + songs.length + " locators\n");
}

function scanLocators() {
    var liveSet = new LiveAPI("live_set");
    var count = parseInt(liveSet.getcount("cue_points"));

    var list = [];
    for (var i = 0; i < count; i++) {
        var cue = new LiveAPI("live_set cue_points " + i);
        list.push({
            idx:  i,                           // Live's own index — used by jump()
            name: textOf(cue.get("name")),
            time: numberOf(cue.get("time"))
        });
    }

    // Live's index order is not chronological
    list.sort(function (a, b) { return a.time - b.time; });

    // A song ends where the next locator begins. The last locator gets null,
    // meaning no automatic stop — there is nothing after it.
    for (var j = 0; j < list.length; j++) {
        list[j].nextTime = (j + 1 < list.length) ? list[j + 1].time : null;
    }
    songs = list;
}

// ---------------- incoming MIDI ----------------

function ctl(cc, v) {
    if (cc === CC_INIT) { if (v > 0) init(); return; }
    if (!ready) return;

    if (cc === CC_JOG) {
        if (v > 64)      move(1);
        else if (v < 64) move(-1);
        return;
    }
    if (cc === CC_PLAY) { if (v > 0) play(); return; }
    if (cc === CC_STOP) { if (v > 0) stop(); return; }

    for (var i = 0; i < CC_BTN.length; i++) {
        if (cc === CC_BTN[i]) { if (v > 0) toggleArm(i); return; }
    }
}

// ---------------- actions ----------------

function toggleArm(i) {
    if (i >= names.length) return;
    var value = armed[i] ? 0 : 1;
    new LiveAPI("live_set tracks " + i).set("arm", value);
    armed[i] = value;
    drawButton(i);
}

function move(step) {
    if (songs.length === 0) return;
    var previousTop = top;

    cursor += step;
    if (cursor < 0) cursor = 0;
    if (cursor > songs.length - 1) cursor = songs.length - 1;

    clampWindow();
    if (top !== previousTop) drawList();    // the window moved: redraw
    else                     drawCursor();  // otherwise: just move the box
}

function play() {
    if (songs.length === 0) return;
    var song = songs[cursor];

    // Guard OFF while jumping: jumping BACKWARDS puts the new position past
    // the previous song's boundary, and the callback would read that as
    // "song finished" and stop immediately.
    boundaryTime = -1;

    // Live's own locator function. current_song_time cannot be set — it reads
    // back unchanged whatever the transport state. jump() is the way.
    new LiveAPI("live_set cue_points " + song.idx).call("jump");

    if (!playing) new LiveAPI("live_set").call("start_playing");

    // Guard back ON, now that the playhead is in place
    boundaryTime = (song.nextTime !== null) ? song.nextTime : -1;
}

function stop() {
    boundaryTime = -1;                    // a manual stop disables auto-stop
    new LiveAPI("live_set").call("stop_playing");
}

function onIsPlayingChanged(args) {
    if (!args || args.length < 2 || args[0] !== "is_playing") return;
    playing = args[1] ? true : false;
}

// The boundary is the next locator's own position. No durations are computed
// and no tolerance is applied.
function onTimeChanged(args) {
    if (!args || args.length < 2 || args[0] !== "current_song_time") return;
    if (boundaryTime < 0) return;                      // guard is off
    if (!playing) return;                              // only while playing
    if (parseFloat(args[1]) < boundaryTime) return;    // locator not reached yet

    boundaryTime = -1;
    new LiveAPI("live_set").call("stop_playing");
    move(1);                                           // cursor on to the next song
}

// ---------------- screen ----------------

function drawButton(i) {
    var color = armed[i] ? COLOR_ARMED : COLOR_OFF;
    var p = [0x00, 0x02, 0x04, i + 1];                     // footer button id 1-4
    p = p.concat([0x00, armed[i] ? 0x03 : 0x02, 0x00]);    // type: 03 = lit
    p = p.concat([0x03, 0x00, 0x00]);                      // constant, per Arturia's format
    p = p.concat([0x04, color[0], color[1], color[2], 0x00]);
    p = p.concat([0x05]).concat(asciiBytes(names[i], MAX_LABEL)).concat([0x00]);
    enqueue(p);
}

function drawList() {
    var n = songs.length;

    // title + the list's full length (two bytes, high byte first)
    var p = [0x00, 0x02, 0x04, 0x28, 0x00].concat(asciiBytes(TITLE, MAX_LINE));
    p = p.concat([0x00, 0x02, (n >> 7) & 0x7F, n & 0x7F, 0x00]);
    enqueue(p);

    var last = Math.min(top + VISIBLE, n);
    for (var i = top; i < last; i++) {
        var q = [0x00, 0x02, 0x04, 0x15, 0x00].concat(asciiBytes(songs[i].name, MAX_LINE));
        q = q.concat([0x00, 0x02, 0x00, 0x00, 0x03, (i >> 7) & 0x7F, i & 0x7F, 0x00]);
        enqueue(q);
    }
    drawCursor();   // cursor last — every item pushed in moves the box itself
}

function drawCursor() {
    var n = songs.length;
    if (n === 0) return;

    // The number is not the line on screen. The firmware works the line out
    // from it, anchored on line 4 and framed by the list's full length. With
    // the whole list visible the special case matters: without it length - 7
    // goes negative and the box moves backwards.
    var number;
    if (n <= VISIBLE) {
        number = cursor;
    } else {
        var line = cursor - top;
        number = (line <= 3) ? line : line + (n - VISIBLE);
    }
    enqueue([0x00, 0x02, 0x04, 0x15, 0x03, (number >> 7) & 0x7F, number & 0x7F, 0x00]);
}

function clampWindow() {
    var n = songs.length;
    if (cursor < top) top = cursor;
    if (cursor > top + VISIBLE - 1) top = cursor - VISIBLE + 1;
    if (top > n - VISIBLE) top = n - VISIBLE;
    if (top < 0) top = 0;
}

// ---------------- send queue ----------------

function enqueue(payload) {
    queue.push(payload);
    if (!sending) { sending = true; sendNext(); }
}

function sendNext() {
    if (queue.length === 0) { sending = false; return; }
    sendSysex(queue.shift());
    queueTask.schedule(GAP_MS);
}

function sendSysex(payload) {
    var msg = [0xF0, 0x00, 0x20, 0x6B, 0x7F, 0x42];
    for (var i = 0; i < payload.length; i++) msg.push(payload[i] & 0x7F);
    msg.push(0xF7);
    outlet(0, msg);   // the WHOLE packet as ONE list — never byte by byte, which
                      // loses 2-4% of packets on the way to [midiout]
}

// ---------------- helpers ----------------

function textOf(v) {
    if (v instanceof Array) return v.join(" ");   // LiveAPI splits names on spaces
    return String(v);
}

function numberOf(v) {
    return parseFloat(v instanceof Array ? v[0] : v);
}

var REPLACE = { "\u00e6": "ae", "\u00c6": "Ae", "\u00f8": "oe",
                "\u00d8": "Oe", "\u00e5": "aa", "\u00c5": "Aa" };

function asciiBytes(s, maxlen) {
    s = String(s);
    var clean = "";
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        clean += (REPLACE[c] !== undefined) ? REPLACE[c] : c;
    }
    var out = [];
    for (var j = 0; j < clean.length && out.length < maxlen; j++) {
        var code = clean.charCodeAt(j);
        if (code >= 32 && code <= 126) out.push(code);   // the screen takes plain ASCII only
    }
    return out;
}
